import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/useAuth';

const MainLayout = ({ children }) => {
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const navigation = [
    { to: '/dashboard', label: 'Dashboard', end: true },
    { to: '/applications', label: 'Applications' },
    { to: '/kanban', label: 'Kanban' },
    { to: '/interviews', label: 'Interviews' },
    { to: '/saved-jobs', label: 'Saved Jobs' },
    { to: '/follow-ups', label: 'Follow-Ups' },
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <Link to="/dashboard" className="brand" aria-label="HireTrack dashboard">HireTrack</Link>
        <nav className="nav-list" aria-label="Main navigation">
          {navigation.map(({ to, label, end }) => (
            <NavLink key={to} to={to} end={end} className={({ isActive }) => isActive ? 'active' : undefined}>
              {label}
            </NavLink>
          ))}
          <NavLink to="/profile" className={({ isActive }) => isActive ? 'active profile-nav-link' : 'profile-nav-link'}>Profile</NavLink>
        </nav>
        {user && <div className="sidebar-account">
          <span className="account-avatar" aria-hidden="true">{user.name?.trim()?.charAt(0)?.toUpperCase() || 'U'}</span>
          <span className="account-copy"><strong>{user.name}</strong><small>{user.email}</small></span>
          <button type="button" className="nav-logout" onClick={handleLogout}>Logout</button>
        </div>}
      </aside>

      <div className="main-panel">
        <header className="topbar">
          <div>
            <span className="eyebrow">Student career workspace</span>
            <h2>Job Application Tracker</h2>
          </div>
          <div className="topbar-actions">
            <span className="welcome-label">{user ? `Hi, ${user.name}` : 'Welcome'}</span>
            <button type="button" className="secondary-btn" onClick={() => navigate('/applications')}>
              List View
            </button>
            <button type="button" className="primary-btn" onClick={() => navigate('/interviews/new')}>
              Schedule Interview
            </button>
          </div>
        </header>

        {children}
      </div>
    </div>
  );
};

export default MainLayout;
