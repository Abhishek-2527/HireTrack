import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import DashboardChart from '../components/DashboardChart';
import StatusBadge from '../components/StatusBadge';
import { getAnalytics } from '../services/api';
import { formatDateOnly } from '../utils/date';
import { getFollowUpTiming } from '../utils/followUps';

const emptyAnalytics = {
  overview: {},
  applicationsByStatus: [],
  applicationsByJobType: [],
  applicationsByWorkMode: [],
  applicationsOverTime: [],
  interviewsByStatus: [],
  followUps: { pending: 0, completed: 0, overdue: 0 },
  savedJobs: { total: 0, converted: 0, notConverted: 0 },
  recentApplications: [],
  upcomingFollowUps: [],
};

const DashboardPage = () => {
  const [analytics, setAnalytics] = useState(emptyAnalytics);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const loadAnalytics = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const response = await getAnalytics();
      setAnalytics({ ...emptyAnalytics, ...response.data });
    } catch (err) {
      setError(err.message || 'Unable to load analytics.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const timeoutId = setTimeout(loadAnalytics, 0);
    return () => clearTimeout(timeoutId);
  }, [loadAnalytics]);

  const overview = analytics.overview || {};
  const cards = [
    ['Total Applications', overview.totalApplications],
    ['Interviews', overview.totalInterviews],
    ['Offers', overview.totalOffers],
    ['Saved Jobs', overview.totalSavedJobs],
    ['Pending Follow-ups', overview.pendingFollowUps],
    ['Rejected', overview.totalRejected],
  ];

  return (
    <main className="page-shell dashboard-page">
      <div className="stats-grid dashboard-metric-grid">
        {cards.map(([label, value]) => (
          <div className="card stat-card" key={label}>
            <span>{label}</span>
            <strong>{loading || error ? '—' : value || 0}</strong>
          </div>
        ))}
      </div>

      {error && <div className="error-banner" role="alert">{error.startsWith('Unable to load analytics') ? 'Unable to load analytics.' : `Unable to load analytics. ${error}`} <button type="button" className="text-link" onClick={loadAnalytics}>Retry</button></div>}

      <div className="card hero-card">
        <p className="eyebrow">Track. Apply. Interview. Get Hired.</p>
        <h1>HireTrack Dashboard</h1>
        <p className="muted-text">Your job search activity at a glance.</p>
      </div>

      <section className="dashboard-section">
        <div className="section-heading"><div><p className="eyebrow">Your activity</p><h2>Application Analytics</h2></div></div>
        {loading ? <div className="card loading-card"><p>Loading analytics...</p></div> : error ? null : analytics.overview?.totalApplications ? (
          <div className="analytics-grid">
            <DashboardChart title="Applications Over Time" description="Monthly applications · last 6 months" data={analytics.applicationsOverTime} labelKey="month" />
            <DashboardChart title="Applications by Status" data={analytics.applicationsByStatus} labelKey="status" />
            <DashboardChart title="Applications by Job Type" data={analytics.applicationsByJobType} labelKey="jobType" />
            <DashboardChart title="Applications by Work Mode" data={analytics.applicationsByWorkMode} labelKey="workMode" />
            <DashboardChart title="Interviews by Status" data={analytics.interviewsByStatus} labelKey="status" />
          </div>
        ) : (
          <div className="card analytics-no-data"><h3>No application data yet.</h3><p>Start adding job applications to see your analytics.</p><Link to="/applications/new" className="primary-btn link-btn">Add Application</Link></div>
        )}
      </section>

      <section className="card dashboard-insights">
        <div className="section-heading"><div><p className="eyebrow">Saved Jobs</p><h2>Saved Job Progress</h2></div><Link to="/saved-jobs" className="text-link">View Saved Jobs</Link></div>
        <div className="saved-job-insights">
          <div><span>Total Saved</span><strong>{loading || error ? '—' : analytics.savedJobs?.total || 0}</strong></div>
          <div><span>Converted</span><strong>{loading || error ? '—' : analytics.savedJobs?.converted || 0}</strong></div>
          <div><span>Not Converted</span><strong>{loading || error ? '—' : analytics.savedJobs?.notConverted || 0}</strong></div>
        </div>
      </section>

      <section className="card dashboard-follow-ups">
        <div className="section-heading"><div><p className="eyebrow">Next steps</p><h2>Upcoming Follow-Ups</h2></div><Link to="/follow-ups" className="text-link">View All</Link></div>
        {loading ? <p className="muted-text">Loading follow-ups...</p> : error ? null : analytics.upcomingFollowUps.length === 0 ? (
          <p className="muted-text">No pending follow-ups. Add a follow-up date to an application to plan your next touchpoint.</p>
        ) : (
          <div className="dashboard-follow-up-list">{analytics.upcomingFollowUps.map((item) => (
            <Link key={item._id} className="dashboard-follow-up-row" to={`/applications/${item._id}`}>
              <span><strong>{item.companyName}</strong><small>{item.jobTitle}</small></span>
              <span>{formatDateOnly(item.followUpDate)} · {getFollowUpTiming(item).label}</span>
            </Link>
          ))}</div>
        )}
      </section>

      <section className="card dashboard-recent-applications">
        <div className="section-heading"><div><p className="eyebrow">Latest activity</p><h2>Recent Applications</h2></div><Link to="/applications" className="text-link">View All</Link></div>
        {loading ? <p className="muted-text">Loading applications...</p> : error ? null : analytics.recentApplications.length === 0 ? (
          <p className="muted-text">No applications yet. Add your first opportunity to get started.</p>
        ) : (
          <div className="table-wrapper"><table className="data-table"><thead><tr><th>Company</th><th>Job Title</th><th>Status</th><th>Application Date</th></tr></thead>
            <tbody>{analytics.recentApplications.map((application) => <tr key={application._id}>
              <td><Link to={`/applications/${application._id}`}>{application.companyName}</Link></td>
              <td>{application.jobTitle}</td><td><StatusBadge status={application.status} /></td><td>{formatDateOnly(application.applicationDate)}</td>
            </tr>)}</tbody>
          </table></div>
        )}
      </section>
    </main>
  );
};

export default DashboardPage;
